package com.example.pvpvisual;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class SettingsScreen extends Screen {

    public SettingsScreen() {
        super(Text.literal("PvP Visual Ayarları"));
    }

    @Override
    protected void init() {
        int x = width / 2 - 100;
        int y = height / 2 - 70;

        ButtonWidget accentBtn = ButtonWidget.builder(accentText(), b -> {
            Settings.accentIndex = (Settings.accentIndex + 1) % Settings.NEON.length;
            b.setMessage(accentText());
        }).dimensions(x, y, 200, 20).build();
        addDrawableChild(accentBtn);

        ButtonWidget jumpColorBtn = ButtonWidget.builder(jumpText(), b -> {
            Settings.jumpIndex = (Settings.jumpIndex + 1) % Settings.NEON.length;
            b.setMessage(jumpText());
        }).dimensions(x, y + 26, 200, 20).build();
        addDrawableChild(jumpColorBtn);

        addDrawableChild(toggle(x, y + 52, "Jump Circle", () -> Settings.jumpCircle, v -> Settings.jumpCircle = v));
        addDrawableChild(toggle(x, y + 78, "FPS Göster", () -> Settings.showFps, v -> Settings.showFps = v));
        addDrawableChild(toggle(x, y + 104, "Crosshair", () -> Settings.showCrosshair, v -> Settings.showCrosshair = v));

        addDrawableChild(ButtonWidget.builder(Text.literal("Kapat"), b -> close())
                .dimensions(x, y + 140, 200, 20).build());
    }

    private ButtonWidget toggle(int x, int y, String label, BooleanSupplier get, Consumer<Boolean> set) {
        return ButtonWidget.builder(toggleText(label, get.getAsBoolean()), b -> {
            boolean next = !get.getAsBoolean();
            set.accept(next);
            b.setMessage(toggleText(label, next));
        }).dimensions(x, y, 200, 20).build();
    }

    private Text accentText() {
        return Text.literal("Ana renk: " + Settings.NEON_NAMES[Settings.accentIndex]);
    }

    private Text jumpText() {
        return Text.literal("Jump circle rengi: " + Settings.NEON_NAMES[Settings.jumpIndex]);
    }

    private Text toggleText(String label, boolean on) {
        return Text.literal(label + ": " + (on ? "Açık" : "Kapalı"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 95, Settings.accent());
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
