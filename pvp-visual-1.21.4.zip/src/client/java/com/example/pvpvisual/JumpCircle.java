package com.example.pvpvisual;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.DustParticleEffect;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class JumpCircle {

    private static final int MAX_AGE = 14;
    private static final double MAX_RADIUS = 1.4;
    private static final int POINTS = 20;

    // {x, y, z, age}
    private static final List<double[]> circles = new ArrayList<>();
    private static boolean wasOnGround = true;

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(JumpCircle::tick);
    }

    private static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) {
            circles.clear();
            return;
        }

        boolean onGround = mc.player.isOnGround();
        if (wasOnGround && !onGround && mc.player.getVelocity().y > 0 && Settings.jumpCircle) {
            circles.add(new double[]{mc.player.getX(), mc.player.getY(), mc.player.getZ(), 0});
        }
        wasOnGround = onGround;

        Vector3f rgb = toVector(Settings.jumpColor());
        DustParticleEffect effect = new DustParticleEffect(rgb, 1.0f);

        Iterator<double[]> it = circles.iterator();
        while (it.hasNext()) {
            double[] c = it.next();
            int age = (int) c[3];
            if (age >= MAX_AGE) {
                it.remove();
                continue;
            }

            double radius = (age / (double) MAX_AGE) * MAX_RADIUS;
            for (int i = 0; i < POINTS; i++) {
                double angle = (Math.PI * 2 * i) / POINTS;
                double px = c[0] + Math.cos(angle) * radius;
                double pz = c[2] + Math.sin(angle) * radius;
                mc.world.addParticleClient(effect, px, c[1] + 0.05, pz, 0, 0, 0);
            }
            c[3] = age + 1;
        }
    }

    private static Vector3f toVector(int color) {
        return new Vector3f(
                ((color >> 16) & 0xFF) / 255f,
                ((color >> 8) & 0xFF) / 255f,
                (color & 0xFF) / 255f
        );
    }
}
