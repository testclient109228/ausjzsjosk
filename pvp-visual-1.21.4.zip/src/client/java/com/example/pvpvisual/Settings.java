package com.example.pvpvisual;

public final class Settings {
    public static final int[] NEON = {0xFF2BD9, 0x00F0FF, 0x39FF14, 0xBF00FF, 0xFFF01F, 0xFF6A00, 0xFFFFFF};
    public static final String[] NEON_NAMES = {"Pembe", "Mavi", "Yeşil", "Mor", "Sarı", "Turuncu", "Beyaz"};

    public static int accentIndex = 1;
    public static int jumpIndex = 0;
    public static boolean jumpCircle = true;
    public static boolean showFps = true;
    public static boolean showCrosshair = true;

    public static int accent() {
        return 0xFF000000 | NEON[accentIndex];
    }

    public static int jumpColor() {
        return NEON[jumpIndex];
    }
}
