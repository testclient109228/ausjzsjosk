package com.example.pvpvisual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudLayerRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.IdentifiedLayer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class PvpVisualClient implements ClientModInitializer {

    private static final int HEALTH_BG = 0xAA000000;
    private static final int TEXT_COLOR = 0xFFFFFFFF;
    private static final int ABSORPTION_FG = 0xFFFFD700;

    private static final RegistryKey<Potion> HEALING =
            RegistryKey.of(RegistryKeys.POTION, Identifier.of("minecraft", "healing"));
    private static final RegistryKey<Potion> STRONG_HEALING =
            RegistryKey.of(RegistryKeys.POTION, Identifier.of("minecraft", "strong_healing"));

    private static final KeyBinding MENU_KEY = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.pvpvisual.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, KeyBinding.Category.MISC));

    @Override
    public void onInitializeClient() {
        JumpCircle.init();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (MENU_KEY.wasPressed()) {
                mc.setScreen(new SettingsScreen());
            }
        });

        HudLayerRegistrationCallback.EVENT.register(layeredDrawer -> {
            layeredDrawer.attachLayerAfter(
                IdentifiedLayer.CHAT,
                Identifier.of("pvpvisual", "overlay")
            ).attachLayer((context, tickCounter) -> render(context));
        });
    }

    private void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();

        renderHurtFlash(ctx, mc, w, h);
        if (Settings.showCrosshair) renderCrosshair(ctx, w, h);
        if (Settings.showFps) renderFps(ctx, mc);
        renderHealthBar(ctx, mc, w, h);
        renderArmor(ctx, mc, h);
        renderCounters(ctx, mc, w, h);
    }

    private void renderHurtFlash(DrawContext ctx, MinecraftClient mc, int w, int h) {
        int hurt = mc.player.hurtTime;
        if (hurt <= 0) return;
        int alpha = Math.min(90, hurt * 12);
        ctx.fill(0, 0, w, h, (alpha << 24) | 0xFF0000);
    }

    private void renderCrosshair(DrawContext ctx, int w, int h) {
        int cx = w / 2;
        int cy = h / 2;
        int gap = 3;
        int len = 5;
        int c = Settings.accent();

        ctx.fill(cx - gap - len, cy, cx - gap, cy + 1, c);
        ctx.fill(cx + gap, cy, cx + gap + len, cy + 1, c);
        ctx.fill(cx, cy - gap - len, cx + 1, cy - gap, c);
        ctx.fill(cx, cy + gap, cx + 1, cy + gap + len, c);
    }

    private void renderFps(DrawContext ctx, MinecraftClient mc) {
        ctx.drawTextWithShadow(mc.textRenderer, "FPS: " + mc.getCurrentFps(), 4, 4, Settings.accent());
    }

    private void renderHealthBar(DrawContext ctx, MinecraftClient mc, int w, int h) {
        float health = mc.player.getHealth();
        float maxHealth = mc.player.getMaxHealth();
        float absorption = mc.player.getAbsorptionAmount();

        int barW = 100;
        int barH = 6;
        int x = w / 2 - barW / 2;
        int y = h - 52;

        ctx.fill(x - 1, y - 1, x + barW + 1, y + barH + 1, HEALTH_BG);
        float ratio = Math.max(0f, Math.min(1f, health / maxHealth));
        ctx.fill(x, y, x + Math.round(barW * ratio), y + barH, Settings.accent());

        if (absorption > 0) {
            float absRatio = Math.min(1f, absorption / maxHealth);
            ctx.fill(x, y + barH + 1, x + Math.round(barW * absRatio), y + barH + 3, ABSORPTION_FG);
        }

        String text = String.format("%.1f", health) + (absorption > 0 ? " +" + Math.round(absorption) : "");
        ctx.drawCenteredTextWithShadow(mc.textRenderer, text, w / 2, y - 10, TEXT_COLOR);
    }

    private void renderArmor(DrawContext ctx, MinecraftClient mc, int h) {
        int x = 4;
        int y = h - 70;
        int i = 0;
        for (ItemStack stack : mc.player.getInventory().armor) {
            if (!stack.isEmpty() && stack.isDamageable()) {
                int max = stack.getMaxDamage();
                int left = max - stack.getDamage();
                int percent = (int) Math.round(left * 100.0 / max);
                int color = percent > 50 ? 0xFFFFFFFF : percent > 20 ? 0xFFFFFF55 : 0xFFFF5555;
                ctx.drawTextWithShadow(mc.textRenderer, percent + "%", x, y + i * 12, color);
            }
            i++;
        }
    }

    private void renderCounters(DrawContext ctx, MinecraftClient mc, int w, int h) {
        int totems = 0;
        int pots = 0;

        for (int slot = 0; slot < mc.player.getInventory().size(); slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.isOf(Items.TOTEM_OF_UNDYING)) totems += stack.getCount();
            else if (isHealingPotion(stack)) pots += stack.getCount();
        }

        ItemStack offhand = mc.player.getOffHandStack();
        if (offhand.isOf(Items.TOTEM_OF_UNDYING)) totems += offhand.getCount();
        else if (isHealingPotion(offhand)) pots += offhand.getCount();

        int x = w - 80;
        int y = h - 24;
        ctx.drawTextWithShadow(mc.textRenderer, "Totem: " + totems, x, y, totems > 0 ? 0xFFFFD700 : 0xFF888888);
        ctx.drawTextWithShadow(mc.textRenderer, "Pot: " + pots, x, y + 10, pots > 0 ? 0xFFFF88FF : 0xFF888888);
    }

    private boolean isHealingPotion(ItemStack stack) {
        if (!stack.isOf(Items.SPLASH_POTION)) return false;
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) return false;
        return contents.potion()
                .map(entry -> entry.matchesKey(HEALING) || entry.matchesKey(STRONG_HEALING))
                .orElse(false);
    }
}
